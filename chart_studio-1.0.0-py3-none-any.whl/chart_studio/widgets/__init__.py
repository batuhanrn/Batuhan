from __future__ import absolute_import

from chart_studio.widgets.graph_widget import GraphWidget
